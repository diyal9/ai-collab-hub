#!/bin/bash
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" &>/dev/null && pwd)"
echo ">>> Starting Agent Bridge..."
exec "$DIR/agent-bridge-linux-amd64" -config "$DIR/config.yaml"
