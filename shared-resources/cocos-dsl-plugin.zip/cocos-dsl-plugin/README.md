# Cocos DSL Plugin

Cocos Creator 3.8 编辑器插件，将 JSON DSL 转换为场景节点树。

## 架构

```
┌─────────────────────────────────────────────────┐
│                   Main Process                   │
│  (Node.js — 文件选择 / UUID 解析 / 消息路由)      │
│                                                   │
│  menu: 导入JSON / 导入剪贴板 / 导出选中           │
│  ↓ 解析 db:// 路径 → UUID                         │
│  ↓ execute-scene-script(payload)                 │
└──────────────────────┬──────────────────────────┘
                       │
                       ▼
┌─────────────────────────────────────────────────┐
│                   Scene Process                   │
│  (Browser — cc.Node / cc.Component / 资源加载)    │
│                                                   │
│  parse DSL → new Node() → addComponent()          │
│  loadAny(uuid) → SpriteFrame / Font              │
│  Widget.updateAlignment()                         │
└─────────────────────────────────────────────────┘
```

## 安装

1. 将 `cocos-dsl-plugin` 文件夹复制到项目的 `extensions/` 目录：
   ```
   your-project/
   └── extensions/
       └── cocos-dsl-plugin/
           ├── package.json
           ├── i18n/
           │   └── zh.js
           └── dist/
               ├── main.js
               └── scene.js
   ```

2. 重启 Cocos Creator 编辑器
3. 在顶部菜单栏找到 **DSL 工具** 菜单

## 使用

### 从 JSON 文件导入
- 菜单：**DSL 工具 → 从 JSON 文件导入**
- 选择 JSON 文件，插件自动解析并构建节点树

### 从剪贴板导入
- 菜单：**DSL 工具 → 从剪贴板导入**（快捷键 `Ctrl+Shift+V`）
- 将 JSON 复制到剪贴板后点击菜单

### 构建目标
- 如果**有选中节点**，生成的节点树作为该节点的子节点
- 如果**没有选中**，添加到场景根节点

### 导出选中节点为 JSON
- 菜单：**DSL 工具 → 导出选中为 JSON**
- 将场景节点树反向序列化为 DSL JSON

## DSL 规范

### 节点定义
```json
{
  "name": "节点名",
  "active": true,
  "components": [...],
  "children": [...]
}
```

### 支持的组件

| 组件 | 类型标识 | 关键属性 |
|------|----------|----------|
| UITransform | `cc.UITransform` | contentSize, anchorPoint, priority |
| Sprite | `cc.Sprite` | spriteFrame(db://路径), type_enum, color |
| Label | `cc.Label` | string, fontSize, color, overflow, horizontalAlign |
| Widget | `cc.Widget` | isAlignLeft/Right/Top/Bottom, left/right/top/bottom |
| Button | `cc.Button` | transition, normalSprite, pressedSprite |
| Layout | `cc.Layout` | layoutType, resizeMode, spacingX/Y, padding |
| ScrollView | `cc.ScrollView` | horizontal, vertical, inertia, content(子节点名引用) |
| 自定义组件 | 类名如 `ActivityUI` | props (属性键值对) |

### Widget 布局优先

AI 生成时应**优先使用 Widget 约束**而非绝对 position，确保多分辨率兼容：

```json
{
  "type": "cc.Widget",
  "isAlignLeft": true,
  "isAlignRight": true,
  "left": 20,
  "right": 20
}
```

### 资源路径

所有资源使用 `db://assets/` 路径，插件 Main Process 自动解析为 UUID：

```json
{
  "type": "cc.Sprite",
  "spriteFrame": "db://assets/resources/ui/bg.png"
}
```

### 完整示例

见 `examples/activity_main_panel.json` — 包含标题栏、滚动列表、底部栏的完整活动 UI。

## AI 集成

配合 AI 使用时，让 AI 输出 JSON DSL 而非直接生成 TypeScript 代码：

1. **给 AI 的 Prompt 示例**：
   ```
   根据这个 UI 设计图，生成符合 Cocos DSL 规范的 JSON。
   使用 Widget 约束进行布局，资源路径用 db://assets/ 前缀。
   ```

2. **AI 输出 → 剪贴板 → 导入**，一键生成节点树

3. **微调**：生成后在编辑器中手动调整细节

## 注意事项

- **Texture vs SpriteFrame**：插件自动处理 loadAny 返回 Texture2D 时转 SpriteFrame
- **ScrollView content**：通过子节点 name 引用，不是路径
- **自定义组件**：确保组件脚本已注册到引擎
- **UUID 解析**：资源必须存在于项目中，否则跳过并打印警告

## Schema 校验

完整的 JSON Schema 见 `dsl-schema.json`，可用于 AI 输出校验：

```bash
# 使用 ajv-cli 校验
ajv validate -s dsl-schema.json -d your_dsl.json
```
