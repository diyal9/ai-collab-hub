module.exports = {
    menu: {
        dsl: 'DSL 工具',
        import_from_json: '从 JSON 文件导入',
        import_from_clipboard: '从剪贴板导入',
        clear_scene_selection: '清除选中'
    }
};
