#!/bin/bash
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" &>/dev/null && pwd)"
echo ">>> Starting Agent Sandbox..."
exec "$DIR/agent-sandbox-linux-amd64" -config "$DIR/config.yaml"
